export default {
  state: {
    pure: {},
    kmeans: {},
    mds: {},
    pca: {},
    soma: {},
    methodData: {},
  },
};
