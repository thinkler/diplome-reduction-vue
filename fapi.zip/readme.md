Run Flask server:

FLASK_APP=app.py FLASK_DEBUG=1 python -m flask run

Run Vue server:

Got to ./front + nmp start